setGeneric("favorited", function(object, ...)
    standardGeneric("favorited"))

setGeneric("screenName", function(object, ...)
           standardGeneric("screenName"))

setGeneric("replyToSN", function(object, ...)
           standardGeneric("replyToSN"))

setGeneric("created", function(object, ...)
           standardGeneric("created"))

setGeneric("truncated", function(object, ...)
           standardGeneric("truncated"))

setGeneric("replyToSID", function(object, ...)
           standardGeneric("replyToSID"))

setGeneric("id", function(object, ...)
           standardGeneric("id"))

setGeneric("replyToUID", function(object, ...)
           standardGeneric("replyToUID"))

setGeneric("statusSource", function(object, ...)
           standardGeneric("statusSource"))

setGeneric("user", function(object, ...)
           standardGeneric("user"))

setGeneric("description", function(object, ...)
           standardGeneric("description"))

setGeneric("statusesCount", function(object, ...)
           standardGeneric("statusesCount"))

setGeneric("tweetCount", function(object, ...)
           standardGeneric("tweetCount"))

setGeneric("followersCount", function(object, ...)
           standardGeneric("followersCount"))

setGeneric("favoritesCount", function(object, ...)
           standardGeneric("favoritesCount"))

setGeneric("friendsCount", function(object, ...)
           standardGeneric("friendsCount"))

setGeneric("userURL", function(object, ...)
           standardGeneric("userURL"))

setGeneric("name", function(object, ...)
           standardGeneric("name"))

setGeneric("protected", function(object, ...)
           standardGeneric("protected"))

setGeneric("verified", function(object, ...)
           standardGeneric("verified"))

setGeneric("location", function(object, ...)
           standardGeneric("location"))

setGeneric("lastStatus", function(object, ...)
           standardGeneric("lastStatus"))

setGeneric("recipientSN", function(object, ...)
           standardGeneric("recipientSN"))

setGeneric("recipientID", function(object, ...)
           standardGeneric("recipientID"))

setGeneric("sender", function(object, ...)
           standardGeneric("sender"))

setGeneric("recipient", function(object, ...)
           standardGeneric("recipient"))

setGeneric("senderID", function(object, ...)
           standardGeneric("senderID"))

setGeneric("senderSN", function(object, ...)
           standardGeneric("senderSN"))

setGeneric("statusText", function(object, ...)
           standardGeneric("statusText"))
